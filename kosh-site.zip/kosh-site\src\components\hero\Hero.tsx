"use client";

import "./hero.css";
import { useEffect, useRef, type CSSProperties } from "react";
import { AppPhone, NavBar, PhoneBody } from "../app/AppPhone";
import { HomeBody } from "../app/Screens";
import { Icon } from "../app/Icon";
import { rupees } from "@/lib/format";

/** Illustrative synthetic bank messages and how Kosh reads them. Row 7 is deliberately ambiguous. */
const LINES = [
  { raw: "Rs.642.00 debited a/c XX1234 03-11 VPA greenleaf@upi", amt: "642.00", name: "Greenleaf Grocers", icon: "food", cat: "Food", val: -642, c: "#f1a292", mx: 2, my: 1 },
  { raw: "Rs.218.00 debited a/c XX1234 03-11 VPA cityride@upi", amt: "218.00", name: "CityRide", icon: "car", cat: "Transport", val: -218, c: "#6fbfa3", mx: 52, my: 1 },
  { raw: "Rs.85,000.00 credited a/c XX5678 01-11 Acme Payroll", amt: "85,000.00", name: "Acme Payroll", icon: "down", cat: "Salary", val: 85000, c: "#b7d5ae", mx: 2, my: 12 },
  { raw: "Rs.499.00 debited a/c XX1234 02-11 VPA streambox@upi", amt: "499.00", name: "StreamBox", icon: "play", cat: "Subscriptions", val: -499, c: "#c8a7db", mx: 52, my: 12 },
  { raw: "Rs.280.00 debited a/c XX1234 02-11 VPA bean.brew@upi", amt: "280.00", name: "Bean & Brew", icon: "food", cat: "Food", val: -280, c: "#f1a292", mx: 2, my: 1, hide: true },
  { raw: "Rs.22,000.00 debited a/c XX1234 01-11 NEFT Rent", amt: "22,000.00", name: "Rent", icon: "home", cat: "Rent", val: -22000, c: "#d5a64f", mx: 2, my: 1, hide: true },
  { raw: "Rs.1,500.00 debited a/c XX1234 04-11 VPA 98xxxxxx10@upi", amt: "1,500.00", name: "Unknown payee", icon: "search", cat: "Needs review", val: -1500, c: "#e5a63a", mx: 2, my: 1, hide: true, review: true },
];

const START = (i: number) => 0.02 + i * 0.085;
const DUR = 0.3;
const eased = (p: number, i: number) => { const t = Math.min(1, Math.max(0, (p - START(i)) / DUR)); return t * t * (3 - 2 * t); };

export function Hero() {
  const track = useRef<HTMLDivElement>(null);
  const count = useRef<HTMLSpanElement>(null);
  const status = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = track.current;
    if (!el) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)");
    let raf = 0;
    const write = () => {
      raf = 0;
      let p = 1;
      if (!reduce.matches) {
        const r = el.getBoundingClientRect();
        const span = r.height - window.innerHeight;
        p = span > 0 ? Math.min(1, Math.max(0, -r.top / span)) : 1;
      }
      el.style.setProperty("--p", p.toFixed(4));
      const done = LINES.filter((_, i) => eased(p, i) > 0.98).length;
      if (count.current) count.current.textContent = String(done);
      if (status.current) status.current.textContent = p < 0.04 ? "Waiting to be read" : done < LINES.length ? "Reading messages on-device" : "6 sorted · 1 for you to review";
    };
    const queue = () => { if (!raf) raf = requestAnimationFrame(write); };
    write();
    window.addEventListener("scroll", queue, { passive: true });
    window.addEventListener("resize", queue);
    reduce.addEventListener("change", queue);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("scroll", queue); window.removeEventListener("resize", queue); reduce.removeEventListener("change", queue); };
  }, []);

  return (
    <header className="hero-track" ref={track} id="top">
      <div className="hero-sticky shell">
        <div className="hero-copy">
          <p className="hero-kicker"><span className="dot" />Personal finance for salaried India</p>
          <h1 className="hero-h1" aria-label="Finally, money makes sense.">
            <span className="mask" aria-hidden="true"><span style={{ "--k": 0 } as CSSProperties}>Finally, money</span></span>
            <span className="mask" aria-hidden="true"><span style={{ "--k": 1 } as CSSProperties}>makes <em>sense.</em></span></span>
          </h1>
          <p className="hero-sub">Your spending, salary, savings and wealth&nbsp;— together in one clear picture.</p>
          <div className="hero-actions">
            <a href="#early-access" className="btn btn-primary">Get early access <span className="arr" aria-hidden="true">→</span></a>
            <a href="#product" className="hero-link">Explore Kosh</a>
          </div>
          <p className="hero-note">Android beta coming soon.</p>

          <div className="readout" aria-hidden="true">
            <div className="readout-row"><span>Bank messages</span><b><span ref={count}>0</span> / {LINES.length} read</b></div>
            <div className="readout-bar"><i /></div>
            <div className="readout-row"><span ref={status}>Waiting to be read</span><span>On your device</span></div>
          </div>
        </div>

        <div className="stage" role="img" aria-label="Illustration: raw bank messages are read, categorised and resolved into one clear monthly overview in the Kosh Android app.">
          <div className="stage-glow" />
          <div className="stage-phone">
            <div className="hero-phone-in">
              <AppPhone className="hero-phone-wrap">
                <div style={{ position: "relative", flex: 1, display: "flex", flexDirection: "column", minHeight: 0 }}>
                  <div className="layer layer-a">
                    <PhoneBody>
                      <div className="ui-bar"><span className="ui-title">Activity</span><span className="sorting-status"><b>{LINES.length} found</b></span></div>
                      <div className="ui-eyebrow" style={{ margin: "1cqw 0 2.6cqw" }}>Reading your bank messages…</div>
                      {LINES.map((l, i) => (
                        <div className="sorting-slot" style={{ "--i": i, "--s": START(i) + 0.17 } as CSSProperties} key={l.name}>
                          <div className="ui-row">
                            <span className="ui-tile" style={l.review ? { color: "#e5a63a" } : l.val > 0 ? { background: "#232b21", color: "#b7d5ae" } : undefined}><Icon name={l.icon} /></span>
                            <div className="ui-main"><strong>{l.name}</strong><span style={l.review ? { color: "#e5a63a", fontWeight: 700 } : undefined}>{l.cat}</span></div>
                            <span className={`ui-amt ${l.val > 0 ? "ui-pos" : ""}`}>{l.val > 0 ? "+" : "−"}{rupees(Math.abs(l.val))}</span>
                          </div>
                        </div>
                      ))}
                    </PhoneBody>
                    <NavBar active="activity" />
                  </div>
                  <div className="layer layer-b donut-k">
                    <HomeBody />
                    <NavBar active="home" />
                  </div>
                </div>
              </AppPhone>
            </div>
          </div>

          <div className="result" aria-hidden="true">
            <small>Spent in November</small>
            <strong>{rupees(38420)}</strong>
            <div className="bars">
              {[["Rent", 57, "#b8801f"], ["Food", 18, "#e08a7d"], ["Bills", 8, "#5b8db8"]].map(([n, w, c]) => (
                <div className="bar" key={n as string} style={{ "--w": w, "--c": c } as CSSProperties}><span>{n}</span><i /><b>{w}%</b></div>
              ))}
            </div>
          </div>

          <ul className="raw" aria-hidden="true">
            {LINES.map((l, i) => {
              const [pre, post] = l.raw.split(l.amt);
              return (
                <li key={l.name} className={`raw-line${l.hide ? " m-hide" : ""}`} style={{ "--i": i, "--s": START(i), "--mx": l.mx, "--my": l.my } as CSSProperties}>
                  <span className="raw-in">{pre}<mark>{l.amt}</mark>{post}</span>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </header>
  );
}
