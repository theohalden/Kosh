import { Reveal } from "../Reveal";

const DIARY: { d: string; t: string }[] = [
  { d: "1 Nov", t: "Salary lands. ₹85,000. It feels like plenty." },
  { d: "2 Nov", t: "Rent goes out. Then the first of a hundred small UPI payments." },
  { d: "9 Nov", t: "You open your bank app. It shows a balance, not a story." },
  { d: "14 Nov", t: "EMI day. There’s probably enough in that account. Probably." },
  { d: "19 Nov", t: "You open the spreadsheet. Last updated: August." },
  { d: "30 Nov", t: "Month-end. You didn’t overspend. You just can’t say where it all went." },
];

export function Problem() {
  return (
    <section className="on-ink bg-ink text-paper" aria-labelledby="problem-h">
      <div className="shell section">
        <div className="grid gap-16 lg:grid-cols-[0.9fr_1.1fr] lg:gap-24">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <Reveal><span className="eyebrow !text-paper/60">A month, as most of us live it</span></Reveal>
            <Reveal delay={80}>
              <h2 id="problem-h" className="h2 mt-6">Your salary comes in. <em className="text-coral-soft">Where does it all go?</em></h2>
            </Reveal>
            <Reveal delay={160}>
              <p className="lead mt-8 !text-paper/70">Between the rent, the EMI, the SIP and the UPI taps, the answer ends up spread across a few bank apps and a spreadsheet you meant to keep up.</p>
            </Reveal>
          </div>

          <ol className="relative border-l border-paper/20" aria-label="A month of money, day by day">
            {DIARY.map((e, i) => (
              <li key={e.d} className="pb-12 pl-8 last:pb-0 sm:pl-12">
                <Reveal delay={60}>
                  <span className="absolute -left-[5px] mt-3 h-[9px] w-[9px] rounded-full bg-ink ring-1 ring-paper/50" aria-hidden="true" />
                  <time className="text-sm font-bold tracking-wide text-coral-soft">{e.d}</time>
                  <p className={`display mt-2 text-[clamp(1.6rem,3vw,2.5rem)] leading-[1.1] tracking-[-0.02em] ${i === DIARY.length - 1 ? "text-paper" : "text-paper/85"}`}>{e.t}</p>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>

        <Reveal className="mt-24 grid gap-8 border-t border-paper/15 pt-14 md:grid-cols-[1.2fr_auto] md:items-end">
          <p className="display max-w-3xl text-[clamp(2rem,4.4vw,3.8rem)] leading-[1.02] tracking-[-0.03em]">
            You’re not bad with money. <span className="text-paper/55">Your money is just spread across too many places.</span>
          </p>
          <a href="#product" className="btn !border-paper/40 !text-paper hover:!bg-paper hover:!text-ink border-2">See it as one picture <span aria-hidden="true">↓</span></a>
        </Reveal>
      </div>
    </section>
  );
}
