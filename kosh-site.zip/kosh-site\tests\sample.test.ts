import { describe, expect, it } from "vitest";
import { holdings, leftToSpend, month, netWorth, overview, plan, snapshots, sum, upcomingTotal } from "@/content/sample";
import { rupees } from "@/lib/format";
import { PRICING } from "@/content/site";

describe("illustrative figures stay internally consistent", () => {
  it("overview categories add up to spend", () => expect(sum(overview.categories)).toBe(overview.spent));
  it("plan: month-to-date spend per line equals total spent", () => expect(plan.reduce((a, p) => a + p.spent, 0)).toBe(month.spent));
  it("plan: lines + unallocated = income", () => expect(plan.reduce((a, p) => a + p.plan, 0) + 10940).toBe(month.income));
  it("left to spend = income - spent - upcoming = unallocated + remaining discretionary", () => {
    expect(leftToSpend).toBe(19140);
    expect(upcomingTotal).toBe(27440);
    const discretionary = plan.filter((p) => ["Food", "Transport", "Fun & shopping", "Other"].includes(p.label)).reduce((a, p) => a + p.plan - p.spent, 0);
    expect(10940 + discretionary).toBe(leftToSpend);
  });
  it("upcoming EMI/SIP/bills match the plan lines", () => {
    const by = (n: string) => month.upcoming.filter((u) => n.split("|").includes(u.name)).reduce((a, u) => a + u.amount, 0);
    expect(by("Loan EMI")).toBe(plan.find((p) => p.label === "Loan EMI")!.plan);
    expect(by("Monthly SIP")).toBe(plan.find((p) => p.label === "Savings & SIP")!.plan);
    const bills = plan.find((p) => p.label === "Bills")!;
    expect(bills.spent + by("Electricity|Broadband")).toBe(bills.plan);
  });
  it("bank balances on Home tie to net-worth bank bucket; snapshots end at net worth", () => {
    expect(month.accounts.reduce((a, x) => a + x.balance, 0)).toBe(netWorth.assets[0].value);
    expect(snapshots.at(-1)!.v).toBe(1146000);
  });
  it("net worth = assets − liabilities (₹11,46,000)", () => {
    expect(sum(netWorth.assets) - sum(netWorth.liabilities)).toBe(1146000);
    expect(sum(netWorth.assets)).toBe(1599500);
  });
  it("investment holdings & retirement tie to the net-worth buckets", () => {
    const by = (ids: string[]) => holdings.filter((h) => ids.includes(h.id)).reduce((a, h) => a + h.value, 0);
    expect(by(["stocks", "mf", "fd", "epf", "ppf"])).toBe(netWorth.assets[1].value);
    expect(by(["gold", "other"])).toBe(netWorth.assets[2].value);
  });
  it("formats Indian digit grouping", () => {
    expect(rupees(1146000)).toBe("₹11,46,000");
    expect(rupees(-435000)).toBe("−₹4,35,000");
  });
  it("pricing matches the brief", () => {
    expect(PRICING.plus.monthly).toBe(79);
    expect(PRICING.plus.annual).toBe(699);
    expect(Math.round((1 - 699 / (79 * 12)) * 100)).toBe(26);
  });
});
