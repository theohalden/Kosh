/**
 * Every figure on the marketing site is ILLUSTRATIVE sample data.
 * It is not a real person's money and not a screenshot of a shipping build.
 * Keep totals internally consistent – tests/sample.test.ts checks the arithmetic.
 */

export type Slice = { label: string; value: number; color: string };

/** Month-to-date spending shown in the (existing) Overview screen. */
export const overview = {
  month: "November",
  income: 85000,
  spent: 38420,
  categories: [
    { label: "Rent", value: 22000, color: "#d5a64f" },
    { label: "Food", value: 6940, color: "#f1a292" },
    { label: "Bills", value: 3120, color: "#7fAEdb" },
    { label: "Shopping", value: 2640, color: "#c8a7db" },
    { label: "Transport", value: 2180, color: "#6fbfa3" },
    { label: "Other", value: 1540, color: "#8b8782" },
  ] satisfies Slice[],
};

export type Txn = { merchant: string; category: string; amount: number; when: string; kind: "debit" | "credit"; color: string };

export const transactions: Txn[] = [
  { merchant: "Greenleaf Grocers", category: "Food", amount: 642, when: "Today", kind: "debit", color: "#f1a292" },
  { merchant: "CityRide", category: "Transport", amount: 218, when: "Today", kind: "debit", color: "#6fbfa3" },
  { merchant: "Acme Payroll", category: "Salary", amount: 85000, when: "1 Nov", kind: "credit", color: "#b7d5ae" },
  { merchant: "StreamBox", category: "Subscriptions", amount: 499, when: "2 Nov", kind: "debit", color: "#c8a7db" },
  { merchant: "Bean & Brew", category: "Food", amount: 280, when: "2 Nov", kind: "debit", color: "#f1a292" },
];

/** Planned budget – illustrative. Allocations + free-to-spend must equal income. */
export const budget = {
  income: 85000,
  lines: [
    { label: "Rent", value: 22000, color: "#d5a64f" },
    { label: "Loan EMI", value: 12400, color: "#9a93d9" },
    { label: "Bills", value: 5200, color: "#7faedb" },
    { label: "Savings & SIP", value: 12000, color: "#6fbfa3" },
    { label: "Food", value: 10000, color: "#f1a292" },
    { label: "Transport", value: 3500, color: "#c8a7db" },
    { label: "Fun & shopping", value: 6000, color: "#e08a7d" },
  ] satisfies Slice[],
  freeToSpend: 13900,
  daysLeft: 30,
};

export const bills = [
  { name: "Electricity", due: "12 Nov", amount: 1840 },
  { name: "Broadband", due: "15 Nov", amount: 1200 },
  { name: "Loan EMI", due: "14 Nov", amount: 12400 },
];

/** Planned manual holdings – illustrative. */
export const holdings = [
  { id: "stocks", label: "Stocks", value: 184500, updated: "Updated 2 days ago", hint: "Record each holding, then refresh its value when you check your broker." },
  { id: "mf", label: "Mutual funds", value: 325000, updated: "Updated 5 days ago", hint: "Track units or invested value; update the current value monthly." },
  { id: "fd", label: "Fixed deposits", value: 200000, updated: "Matures Mar 2027", hint: "Principal, rate and maturity date, entered once." },
  { id: "epf", label: "EPF", value: 462000, updated: "Updated 3 weeks ago", hint: "Copy the balance from your passbook whenever you like." },
  { id: "ppf", label: "PPF", value: 120000, updated: "Updated 3 weeks ago", hint: "One balance, one yearly reminder to refresh it." },
  { id: "gold", label: "Gold", value: 96000, updated: "Updated last month", hint: "Grams held and the value you want to carry." },
  { id: "other", label: "Other assets", value: 70000, updated: "Updated last month", hint: "Anything else you want counted: a bike, a deposit, a loan you gave." },
];

export const netWorth = {
  assets: [
    { label: "Bank balances", value: 142000, color: "#7d8f78" },
    { label: "Investments & retirement", value: 1291500, color: "#b8801f" },
    { label: "Gold & other assets", value: 166000, color: "#cdc2a2" },
  ] satisfies Slice[],
  liabilities: [
    { label: "Car loan outstanding", value: 435000, color: "#a05a48" },
    { label: "Credit card due", value: 18500, color: "#cf9887" },
  ] satisfies Slice[],
};

export const sum = (xs: { value: number }[]) => xs.reduce((a, x) => a + x.value, 0);

/* ───────── Home / Plan screens (single source of truth; consistency checked in tests/sample.test.ts) ───────── */
export const month = {
  label: "November",
  today: "8 Nov",
  income: 85000,
  spent: 38420,
  daysLeft: 23,
  upcoming: [
    { name: "Electricity", date: "12 Nov", amount: 1840, icon: "bolt" },
    { name: "Loan EMI", date: "14 Nov", amount: 12400, icon: "calendar" },
    { name: "Broadband", date: "15 Nov", amount: 1200, icon: "bolt" },
    { name: "Monthly SIP", date: "20 Nov", amount: 12000, icon: "wealth" },
  ],
  accounts: [
    { name: "Salary account", mask: "5678", balance: 118430 },
    { name: "Spending account", mask: "1234", balance: 23570 },
  ],
};
export const upcomingTotal = month.upcoming.reduce((a, u) => a + u.amount, 0);
export const leftToSpend = month.income - month.spent - upcomingTotal;

export const plan = [
  { label: "Rent", plan: 22000, spent: 22000, color: "#d5a64f" },
  { label: "Loan EMI", plan: 12400, spent: 0, color: "#9a93d9" },
  { label: "Bills", plan: 6160, spent: 3120, color: "#7faedb" },
  { label: "Savings & SIP", plan: 12000, spent: 0, color: "#6fbfa3" },
  { label: "Food", plan: 10000, spent: 6940, color: "#f1a292" },
  { label: "Transport", plan: 3500, spent: 2180, color: "#c8a7db" },
  { label: "Fun & shopping", plan: 6000, spent: 2640, color: "#e08a7d" },
  { label: "Other", plan: 2000, spent: 1540, color: "#8b8782" },
];

export type Activity = { id: string; name: string; meta: string; amount: number; kind: "out" | "in" | "transfer"; icon: string };
export const activity: { day: string; items: Activity[] }[] = [
  { day: "Today", items: [
    { id: "a1", name: "Greenleaf Grocers", meta: "Food · UPI", amount: 642, kind: "out", icon: "food" },
    { id: "a2", name: "CityRide", meta: "Transport · UPI", amount: 218, kind: "out", icon: "car" },
  ] },
  { day: "Yesterday", items: [
    { id: "a3", name: "Bean & Brew", meta: "Food · UPI", amount: 280, kind: "out", icon: "food" },
    { id: "a4", name: "To savings ••5678", meta: "Transfer · own account", amount: 10000, kind: "transfer", icon: "swap" },
  ] },
  { day: "6 Nov", items: [
    { id: "a5", name: "StreamBox", meta: "Subscriptions · Card ••8841", amount: 499, kind: "out", icon: "play" },
  ] },
  { day: "1 Nov", items: [
    { id: "a6", name: "Acme Payroll", meta: "Salary · NEFT", amount: 85000, kind: "in", icon: "down" },
    { id: "a7", name: "Rent · Meera", meta: "Rent · NEFT", amount: 22000, kind: "out", icon: "home" },
  ] },
];

export const snapshots = [
  { m: "Jun", v: 940000 }, { m: "Jul", v: 975000 }, { m: "Aug", v: 1012000 }, { m: "Sep", v: 1049000 }, { m: "Oct", v: 1094000 }, { m: "Nov", v: 1146000 },
];
