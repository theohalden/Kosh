"use client";

import "./showcase.css";
import { useEffect, useRef, useState } from "react";
import { AppPhone } from "../app/AppPhone";
import { SCREENS } from "../app/Screens";
import type { Tab } from "../app/AppPhone";

const STEPS: { tab: Tab; kicker: string; h: string; p: string; live: boolean; note: string }[] = [
  { tab: "home", kicker: "The whole month", h: "Open Kosh. Know where you stand.", p: "Not just a balance. An answer to the question that actually matters: after the bills, the EMI and the SIP, what is really left to spend?", live: true, note: "Income, spending and recent activity are in the app today. The left-to-spend figure arrives with planning." },
  { tab: "activity", kicker: "Every rupee, sorted", h: "Stop wondering where your money went.", p: "Kosh reads the bank messages already on your phone and builds the history for you: UPI, cards, salary, rent. Search it, filter it, correct anything it got wrong once, and Kosh remembers.", live: true, note: "In the app today." },
  { tab: "plan", kicker: "Salary and planning", h: "Know what’s left after life happens.", p: "Rent, the EMI, the SIP, the broadband bill: they all have a date. Kosh sets them against your salary, so the number you see is the number you can spend.", live: false, note: "In development." },
  { tab: "wealth", kicker: "Wealth and net worth", h: "See everything you’ve worked for, in one place.", p: "Write down what you own (shares, mutual funds, FDs, EPF, PPF, gold) and what you owe. Update a value whenever you check it. Your net worth takes care of itself.", live: false, note: "In development. Manual by design: no broker connections." },
];

export function Showcase() {
  const track = useRef<HTMLDivElement>(null);
  const [step, setStep] = useState(0);

  useEffect(() => {
    const el = track.current;
    if (!el) return;
    let raf = 0;
    const read = () => {
      raf = 0;
      const r = el.getBoundingClientRect();
      const span = r.height - window.innerHeight;
      const p = span > 0 ? Math.min(0.9999, Math.max(0, -r.top / span)) : 0;
      setStep(Math.floor(p * STEPS.length));
    };
    const queue = () => { if (!raf) raf = requestAnimationFrame(read); };
    read();
    window.addEventListener("scroll", queue, { passive: true });
    window.addEventListener("resize", queue);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("scroll", queue); window.removeEventListener("resize", queue); };
  }, []);

  const go = (i: number) => {
    const el = track.current;
    if (!el) return;
    const span = el.offsetHeight - window.innerHeight;
    window.scrollTo({ top: el.offsetTop + ((i + 0.5) / STEPS.length) * span, behavior: "smooth" });
  };

  return (
    <section id="product" ref={track} className="sc-track" aria-labelledby="sc-h">
      <div className="sc-sticky shell">
        <div className="sc-text">
          <h2 id="sc-h" className="sr-only">One calm picture of your whole month</h2>
          <ol className="sc-steps">
            {STEPS.map((s, i) => (
              <li key={s.tab} className="sc-step" data-on={i === step} aria-hidden={i !== step}>
                <p className="sc-kicker"><span>{`0${i + 1}`}</span>{s.kicker}</p>
                <h3 className="sc-h"><span className="mask"><span>{s.h}</span></span></h3>
                <p className="sc-p">{s.p}</p>
                <p className="sc-note"><i className={s.live ? "live" : "dev"} aria-hidden="true" />{s.note}</p>
              </li>
            ))}
          </ol>
          <div className="sc-dots" role="group" aria-label="Product screens">
            {STEPS.map((s, i) => (
              <button key={s.tab} type="button" onClick={() => go(i)} aria-current={i === step} aria-label={`Show ${s.tab} screen`}><span /></button>
            ))}
          </div>
          <p className="sc-disclosure">Screens preview Kosh with sample figures. Home and Activity reflect the app today; Plan and Wealth are still in development.</p>
        </div>

        <div className="sc-stage">
          <div className="sc-phone">
            <AppPhone label={`The Kosh ${STEPS[step].tab} screen, shown with sample figures`}>
              <div className="sc-screens">
                {STEPS.map((s, i) => {
                  const Screen = SCREENS[s.tab];
                  return (
                    <div key={s.tab} className="sc-screen" data-on={i === step} data-past={i < step} aria-hidden="true">
                      <Screen />
                    </div>
                  );
                })}
              </div>
            </AppPhone>
          </div>
        </div>
      </div>
    </section>
  );
}
