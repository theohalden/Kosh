export const REPO_URL = "https://github.com/theohalden/Kosh";
export const SITE_NAME = "Kosh";

export const PRICING = {
  free: { name: "Kosh Free", price: "₹0", features: ["Core expense tracking", "Transaction history", "Automatic and manual categorisation", "Basic monthly summaries"] },
  plus: {
    name: "Kosh Plus",
    monthly: 79,
    annual: 699,
    features: ["Advanced budgeting", "Financial planning", "Investment tracking", "Net-worth insights"],
  },
};

export const FAQS: { q: string; a: string }[] = [
  { q: "What is Kosh?", a: "Kosh is an Android app for salaried people in India who are tired of not knowing where their money went. It reads your bank messages on your phone, files every transaction, and is growing to cover your salary plan, your investments and your net worth, so it all sits in one place." },
  { q: "Is Kosh available now?", a: "Not to the public. The Android app is in early development and its code is open on GitHub, but there’s no download yet, and we won’t offer one until a properly tested release exists. Join the list and we’ll write when the beta opens." },
  { q: "Is it free?", a: "Joining early access is free and needs no payment. The plan is a free tier (core expense tracking, history, categories and basic monthly summaries) and an optional Kosh Plus at a planned ₹79 a month or ₹699 a year. Those prices, and what each plan includes, are preliminary." },
  { q: "Does it work on Android?", a: "Kosh is built for Android 8.0 and newer. It’s Android-only for now, and other platforms aren’t part of the current plan." },
  { q: "How does automatic tracking work?", a: "With your permission, Kosh reads bank and UPI messages on your phone and picks out the amount, account, date and who you paid, then files it under a category. It understands specific message formats (HDFC, Kotak and Slice today, plus a general UPI format), so some messages won’t be recognised and some categories will need a quick fix in the review queue." },
  { q: "Is my financial information uploaded?", a: "No. In the current app, your transactions, the original message text and your categories are stored in a database on your phone. The app doesn’t ask for internet permission and has no analytics or finance-data upload. This website only collects what you type into the early-access form: your email, an optional interest and your consent choice." },
  { q: "Can I track investments?", a: "That’s planned for the beta, as manual tracking: you’ll record shares, mutual funds, fixed deposits, EPF, PPF, gold and other assets, and update their values when you like. Kosh won’t connect to your broker or fetch live prices." },
  { q: "When will early access launch?", a: "There’s no date yet, and we’d rather not promise one. The beta follows a tested, signed Android release. Everyone on the list hears first." },
  { q: "How will I receive an invitation?", a: "By email, at the address you confirmed. After you sign up we send one message asking you to confirm it’s really yours, and only confirmed addresses are invited. You can unsubscribe or ask us to delete your details at any time." },
];
