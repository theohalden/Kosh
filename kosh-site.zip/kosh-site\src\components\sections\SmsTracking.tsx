"use client";

import { useState } from "react";
import { Reveal, LiveChip } from "../Reveal";

const SAMPLES = [
  { id: "grocer", sender: "VK-BANKSMS", text: "Rs.642.00 debited from a/c XX1234 on 03-11-26 to VPA greenleaf@upi. Not you? Call your bank.", parsed: { Amount: "₹642.00", Direction: "Money out", Account: "••1234", Paid: "Greenleaf Grocers", Category: "Food" }, tone: "ok", status: "Filed under Food from the merchant." },
  { id: "salary", sender: "VM-BANKSMS", text: "Rs.85,000.00 credited to a/c XX5678 on 01-11-26 by Acme Payroll. Avl bal Rs.1,18,430.", parsed: { Amount: "₹85,000.00", Direction: "Money in", Account: "••5678", Paid: "Acme Payroll", Category: "Salary" }, tone: "ok", status: "Recognised as your salary." },
  { id: "person", sender: "VK-BANKSMS", text: "Rs.1,500.00 debited from a/c XX1234 on 04-11-26 to VPA 98xxxxxx10@upi. Not you? Call your bank.", parsed: { Amount: "₹1,500.00", Direction: "Money out", Account: "••1234", Paid: "A person", Category: "Needs you" }, tone: "review", status: "Kosh can’t know what this was, so it asks you once. Next time, it remembers." },
] as const;

export function SmsTracking() {
  const [i, setI] = useState(0);
  const s = SAMPLES[i];
  return (
    <section id="features" className="border-t border-line">
      <div className="shell section">
        <div className="grid gap-14 lg:grid-cols-[0.9fr_1.1fr] lg:gap-24">
          <div>
            <Reveal><span className="eyebrow">Expense tracking</span></Reveal>
            <Reveal delay={80}><h2 className="h2 mt-6">Your bank already told you.</h2></Reveal>
            <Reveal delay={160}>
              <p className="lead mt-8">Every debit and credit already reaches you as a text. Kosh reads those messages on your phone, picks out the amount, the account and who you paid, and files it. When it isn’t sure, it asks you once.</p>
            </Reveal>
            <Reveal delay={220}><div className="mt-8"><LiveChip /></div></Reveal>
            <Reveal delay={260}>
              <p className="mt-8 max-w-md border-t border-line pt-5 text-[0.95rem] text-ink-2">
                <strong className="text-ink">Where it works today:</strong> HDFC, Kotak and Slice messages, plus a general UPI format. Messages Kosh doesn’t recognise are skipped, and a category can be wrong. That’s what the review queue is for.
              </p>
            </Reveal>
          </div>

          <Reveal delay={120}>
            <div>
              <p className="text-sm font-bold text-ink-2">Pick a message</p>
              <div role="radiogroup" aria-label="Sample bank messages" className="mt-3 grid gap-2">
                {SAMPLES.map((m, idx) => {
                  const on = idx === i;
                  return (
                    <button key={m.id} role="radio" aria-checked={on} onClick={() => setI(idx)} className={`rounded-[10px] border px-4 py-3.5 text-left transition-colors ${on ? "border-ink bg-card" : "border-line hover:border-ink-3"}`}>
                      <span className="block text-[0.7rem] font-bold tracking-wider text-ink-3">{m.sender}</span>
                      <span className="mt-1 block font-mono text-[0.82rem] leading-snug text-ink-2">{m.text}</span>
                    </button>
                  );
                })}
              </div>
              <div className="mt-3 rounded-[14px] bg-ink p-6 text-paper sm:p-8" aria-live="polite">
                <p className="text-sm font-bold text-paper/55">What Kosh makes of it</p>
                <dl className="mt-5 grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-3">
                  {Object.entries(s.parsed).map(([k, v]) => (
                    <div key={k}>
                      <dt className="text-xs font-semibold text-paper/50">{k}</dt>
                      <dd className={`mt-1 text-[1.1rem] font-bold ${k === "Category" ? (s.tone === "review" ? "text-saffron" : "text-app-positive") : ""}`}>{v}</dd>
                    </div>
                  ))}
                </dl>
                <p className="mt-6 border-t border-paper/15 pt-4 text-[0.95rem] text-paper/80">{s.status}</p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
