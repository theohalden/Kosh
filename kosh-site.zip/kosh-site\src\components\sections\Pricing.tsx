import { Reveal } from "../Reveal";
import { PRICING } from "@/content/site";

const Tick = ({ c = "currentColor" }: { c?: string }) => (
  <svg width="18" height="18" viewBox="0 0 18 18" className="mt-1 flex-none" aria-hidden="true"><path d="M3 9.5 7 13.5l8-9" fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
);

export function Pricing() {
  const { free, plus } = PRICING;
  const perMonth = Math.round(plus.annual / 12);
  const saving = Math.round((1 - plus.annual / (plus.monthly * 12)) * 100);
  return (
    <section id="pricing" className="shell section" aria-labelledby="pricing-h">
      <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-24">
        <div>
          <Reveal><span className="eyebrow">Planned pricing</span></Reveal>
          <Reveal delay={80}><h2 id="pricing-h" className="h2 mt-6">Start free. Add more only if you want it.</h2></Reveal>
          <Reveal delay={160}><p className="lead mt-8">Knowing where your money goes is the part everyone should get. Plus is for people who want to plan ahead and see their wealth too.</p></Reveal>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Reveal>
            <article className="paper-card flex h-full flex-col p-8" aria-labelledby="free-h">
              <h3 id="free-h" className="text-3xl">{free.name}</h3>
              <p className="mt-5 flex items-baseline gap-2"><span className="display num text-[4.6rem] leading-none tracking-[-0.04em]">{free.price}</span></p>
              <p className="mt-1 text-sm text-ink-3">Always the starting point</p>
              <ul className="mt-8 grid gap-3.5 border-t border-line pt-7 text-[0.98rem]">{free.features.map((f) => <li key={f} className="flex gap-3"><Tick c="#2f6b4f" />{f}</li>)}</ul>
            </article>
          </Reveal>
          <Reveal delay={100}>
            <article className="on-ink flex h-full flex-col rounded-[var(--radius-card)] bg-ink p-8 text-paper" aria-labelledby="plus-h">
              <h3 id="plus-h" className="text-3xl">{plus.name}</h3>
              <p className="mt-5 flex items-baseline gap-2"><span className="display num text-[4.6rem] leading-none tracking-[-0.04em]">₹{plus.monthly}</span><span className="text-paper/60">/ month</span></p>
              <p className="mt-1 text-sm text-paper/60">or ₹{plus.annual} a year · about ₹{perMonth} a month, saving ~{saving}%</p>
              <p className="mt-8 border-t border-paper/20 pt-7 text-sm font-bold text-paper/60">Everything in Free, plus (proposed):</p>
              <ul className="mt-4 grid gap-3.5 text-[0.98rem]">{plus.features.map((f) => <li key={f} className="flex gap-3"><Tick c="#d5a64f" />{f}</li>)}</ul>
            </article>
          </Reveal>
        </div>
      </div>
      <Reveal className="mt-14 border-t border-line pt-6">
        <p className="font-bold">Planned pricing. Join early access for free. No payment required.</p>
        <p className="mt-2 max-w-2xl text-sm text-ink-3">Prices and what each plan includes are preliminary and may change. Kosh doesn’t take payments today.</p>
      </Reveal>
    </section>
  );
}
