import type { Metadata, Viewport } from "next";
import { Instrument_Serif, Manrope } from "next/font/google";
import "./globals.css";

const instrument = Instrument_Serif({ subsets: ["latin"], weight: "400", style: ["normal", "italic"], variable: "--font-instrument", display: "swap" });
const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope", display: "swap" });

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: "Kosh — Finally, money makes sense.", template: "%s · Kosh" },
  description: "Kosh is an Android personal finance app for salaried Indians: spending, salary, savings and wealth in one clear picture. Local-first. Join the early-access list.",
  openGraph: { type: "website", siteName: "Kosh", title: "Kosh — Finally, money makes sense.", description: "Your spending, salary, savings and wealth — together in one clear picture. Android beta coming soon.", locale: "en_IN" },
  twitter: { card: "summary_large_image", title: "Kosh — Finally, money makes sense.", description: "Your spending, salary, savings and wealth — together in one clear picture." },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = { themeColor: "#f7f5f0", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN" suppressHydrationWarning className={`${instrument.variable} ${manrope.variable}`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: "document.documentElement.classList.add('js')" }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
