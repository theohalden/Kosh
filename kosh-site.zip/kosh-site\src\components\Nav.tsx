"use client";

import { useEffect, useState } from "react";
import { Logo } from "./Logo";

const LINKS = [
  { href: "#product", label: "Product" },
  { href: "#features", label: "Features" },
  { href: "#how", label: "How it works" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export function Nav() {
  const [open, setOpen] = useState(false);
  const [solid, setSolid] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className={`fixed inset-x-0 top-0 z-50 transition-[background,box-shadow] duration-300 ${solid || open ? "bg-paper/90 backdrop-blur-md shadow-[0_1px_0_rgb(18_20_18/0.08)]" : ""}`}>
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-50 focus:rounded-md focus:bg-ink focus:px-4 focus:py-2 focus:text-paper">Skip to content</a>
      <nav aria-label="Primary" className="shell flex h-[68px] items-center justify-between">
        <a href="#top" aria-label="Kosh home" className="text-ink no-underline"><Logo /></a>
        <ul className="hidden items-center gap-8 text-[0.92rem] font-semibold text-ink-2 md:flex">
          {LINKS.map((l) => (
            <li key={l.href}><a href={l.href} className="relative py-2 no-underline transition-colors hover:text-ink after:absolute after:inset-x-0 after:bottom-0 after:h-px after:origin-left after:scale-x-0 after:bg-ink after:transition-transform hover:after:scale-x-100">{l.label}</a></li>
          ))}
        </ul>
        <div className="flex items-center gap-3">
          <a href="#early-access" className="btn btn-primary !min-h-[44px] !px-5 !text-[0.9rem] max-md:hidden">Early access</a>
          <button type="button" className="grid h-11 w-11 place-items-center rounded-full border-2 border-ink md:hidden" aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen((v) => !v)}>
            <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
              {open ? <path d="M4 4l12 12M16 4L4 16" /> : <path d="M3 6h14M3 14h14" />}
            </svg>
          </button>
        </div>
      </nav>
      {open && (
        <div id="mobile-menu" className="shell border-t border-line pb-6 md:hidden">
          <ul className="flex flex-col">
            {LINKS.map((l) => (
              <li key={l.href} className="border-b border-line/70">
                <a href={l.href} onClick={() => setOpen(false)} className="display flex min-h-14 items-center text-[1.7rem] font-semibold no-underline">{l.label}</a>
              </li>
            ))}
          </ul>
          <a href="#early-access" onClick={() => setOpen(false)} className="btn btn-primary mt-5 w-full">Get early access →</a>
        </div>
      )}
    </div>
  );
}
