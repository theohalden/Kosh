export function LogoMark({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <rect x="3" y="2" width="7" height="28" rx="3.5" fill="currentColor" />
      <path d="M10 17.5 22.2 5.2" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
      <path d="M13.2 15.4 26.4 27" stroke="currentColor" strokeWidth="7" strokeLinecap="round" />
      <circle cx="25.2" cy="6.4" r="4.4" fill="#d8442c" />
    </svg>
  );
}

export function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <LogoMark />
      <span className="display text-[1.7rem] font-semibold tracking-[-0.04em] leading-none">Kosh</span>
    </span>
  );
}
